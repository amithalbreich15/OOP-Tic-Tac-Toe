/**
 * @author Amit Halbreich, 208917393
 * enum which represents a board type of mark
 */
enum Mark {BLANK,X,O }

