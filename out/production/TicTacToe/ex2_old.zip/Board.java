public class Board {
    public int SIZE = 4;
    private int winStreak = 3;
    private boolean boardIsActive = false;
    private int marksCount = 0;
//    private int leftCountX = 0;
//    private int rightCountX = 0;
//    private int upCountX = 0;
//    private int downCountX = 0;
//    private int leftUpCountX = 0;
//    private int leftDownCountX = 0;
//    private int rightUpCountX = 0;
//    private int rightDownCountX = 0;
//    private int leftCountO = 0;
//    private int rightCountO = 0;
//    private int upCountO = 0;
//    private int downCountO = 0;
//    private int leftUpCountO = 0;
//    private int leftDownCountO = 0;
//    private int rightUpCountO = 0;
//    private int rightDownCountO = 0;
//    private boolean isCoordinateAvailable = true;

    private Mark winnerMark;

    private final Mark[][] boardMarks;

    public Board() {
        this.boardMarks = new Mark[SIZE][SIZE];
        this.winnerMark = Mark.BLANK;
        this.boardIsActive = true;
        // initialize the board with BLANK marks in each entry
        initializeBoard();
    }

    public Board(int size) {
        this.SIZE = size;
        this.boardMarks = new Mark[SIZE][SIZE];
        this.winnerMark = Mark.BLANK;
        this.boardIsActive = true;
        // initialize the board with BLANK marks in each entry
        initializeBoard();
    }

    public int getSize() {
        return SIZE;
    }

    private Mark getWinner() {
        return this.winnerMark;
    }

    private void setWinner(Mark mark) {
        this.winnerMark = mark;
    }

    Mark[][] getBoard() {
        return this.boardMarks;
    }

    public boolean putMark(Mark mark, int row, int col) {
        if (row < 0 || col < 0 || row >= SIZE || col >= SIZE) {
            return false;
        }
        if (this.boardMarks[row][col] != Mark.BLANK) {
            return false;
        }
        this.boardMarks[row][col] = mark;
        this.marksCount++;
//        checkForPossibleWin(mark, row, col);
        return true;
    }

    public Mark getMark(int row, int col) {
        if (row < 0 || col < 0 || row >= SIZE || col >= SIZE) {
            return Mark.BLANK;
        }
        return this.boardMarks[row][col];
    }

    /*
     * isFullBoard function - check if the board is full of marks.
     */
    private boolean isBoardFull() {
        return this.marksCount == SIZE * SIZE;
    }

    private void initializeBoard() {
        for (int row = 0; row < this.SIZE; row++) {
            for (int col = 0; col < this.SIZE; col++) {
                this.boardMarks[row][col] = Mark.BLANK;
            }
        }
    }

    /**
     * gameEnded method - a method that checks if the game has ended
     *
     * @return true if tha game has ended (can be ended with a win/draw), false otherwise
     */
    public boolean gameFinished() {
        return !boardIsActive;
    }

    private int extractRow(int Coordinate) {
        return Coordinate / 10;
    }

    private int extractCol(int Coordinate) {
        return Coordinate % 10;
    }

    private boolean isLegalMove(Board board, int Coordinate) {
        int row = extractRow(Coordinate);
        int col = extractCol(Coordinate);
        return row >= 0 && col >= 0 && row < board.getSize() && col < board.getSize();
    }

//    private int[] findNextInStreak(Board board, Mark mark, int[] movesToCheck) {
//        int maxMoves = 8;
//        int[] nextInStreak = new int[maxMoves];
//        for (int move = 0; move < maxMoves; move++) {
//            int row = extractRow(movesToCheck[move]);
//            int col = extractCol(movesToCheck[move]);
//            if ((board.getMark(row, col) == mark) && isLegalMove(board, movesToCheck[move])) {
//                nextInStreak[move] = movesToCheck[move];
//            }
//        }
//        return nextInStreak;
//    }
//
//    private boolean checkDiagonalDown(Mark mark, int row, int col) {
//        int diagonalCount = 1;
//        if (!isLegalMove(this, row*10*(winStreak -1) + col + (winStreak -1))) {
//            return false;
//        }
//        for (int i = 0; i < this.winStreak - 1; i++) {
//            if (this.boardMarks[row+1][col+1] == mark && this.getMark(row,col) == mark)
//            {
//                diagonalCount++;
//                row++;
//                col++;
//            }
//        }
//        return diagonalCount == this.winStreak;
//    }
//
//    private boolean checkDiagonalUp(Mark mark, int row, int col) {
//        int diagonalUpCount = 1;
//        if (!isLegalMove(this, (row*10 + col)-(winStreak -1)*9)) {
//            return false;
//        }
//        for (int i = 0; i < this.winStreak - 1; i++) {
//            if (this.boardMarks[row-1][col+1] == mark && this.getMark(row,col) == mark)
//            {
//                diagonalUpCount++;
//                row--;
//                col++;
//            }
//        }
//        return diagonalUpCount == this.winStreak;
//    }
//
//    private boolean checkHorizontal(Mark mark, int row, int col) {
//        int horizontalCount = 1;
//        if (!isLegalMove(this, row * 10 + col + (winStreak - 1))) {
//            return false;
//        }
//        for (int i = 0; i < this.winStreak -1; i++) {
//            if (this.boardMarks[row][col + 1] == mark && this.getMark(row, col) == mark) {
//                horizontalCount++;
//                col++;
//            }
//        }
//        return horizontalCount == this.winStreak;
//    }
//
//    private boolean checkVertical(Mark mark, int row, int col) {
//        int verticalCount = 1;
//        if (!isLegalMove(this, row*10*(winStreak - 1) + col)) {
//            return false;
//        }
//        for (int i = 0; i < this.winStreak - 1; i++) {
//            if (this.boardMarks[row+1][col] == mark && this.getMark(row,col) == mark)
//            {
//                row++;
//                verticalCount++;
//            }
//        }
//        return verticalCount == this.winStreak;
//    }
//
//    private boolean checkAllDirections(Mark mark) {
//        for (int row = 0; row < this.SIZE; row++) {
//            for (int col = 0; col < this.SIZE; col++) {
//                if (checkVertical(mark, row, col) || checkHorizontal(mark, row, col) ||
//                        checkDiagonalDown(mark, row, col) || checkDiagonalUp(mark, row, col)) {
//                    return true;
//                }
//            }
//        }
//        return false;
//    }

//    private void transposeBoard() {
//        for (int row = 0; row < this.SIZE; row++) {
//            for (int col = 0; col < this.SIZE; col++) {
//                this.boardMarks[row][col] = boardMarks[col][row];
//            }
//        }
//
//    }
//
//    private int[] checkSurroundings(Mark mark, int previousTurns, int coordLevel) {
//        int left = previousTurns - coordLevel;
//        int right = previousTurns + coordLevel;
//        int up = previousTurns - 10 * coordLevel;
//        int down = previousTurns + 10 * coordLevel;
//        int leftUp = previousTurns - 11 * coordLevel;
//        int rightUp = previousTurns + 9 * coordLevel;
//        int leftDown = previousTurns - 9 * coordLevel;
//        int rightDown = previousTurns + 11 * coordLevel;
//        int[] movesToCheck = new int[]{left, right, up, down, leftUp, leftDown, rightUp, rightDown};
//        return findNextInStreak(this, mark, movesToCheck);
//    }
//
//    private boolean findGameWinner(Mark mark, int[] previousInStreak) {
//        int[] nextInStreak = new int[8];
//        for (int i = 0; i < this.winStreak; i++) {
//            for (int direction = 0; direction < 8; direction++) {
//                nextInStreak = checkSurroundings(mark, previousInStreak[direction], 1);
//                previousInStreak = nextInStreak;
////                previousInStreak =nextInStreak;
//                switch (direction) {
//                    case 0 -> {
//                        if (nextInStreak[0] != 0 && mark == Mark.X) {
//                            leftCountX++;
//                        }
//                        if (nextInStreak[0] != 0 && mark == Mark.O) {
//                            leftCountO++;
//                        }
//                    }
//                    case 1 -> {
//                        if (nextInStreak[1] != 0 && mark == Mark.X) {
//                            rightCountX++;
//                        }
//                        if (nextInStreak[1] != 0 && mark == Mark.O) {
//                            rightCountO++;
//                        }
//                    }
//                    case 2 -> {
//                        if (nextInStreak[2] != 0 && mark == Mark.X) {
//                            upCountX++;
//                        }
//                        if (nextInStreak[2] != 0 && mark == Mark.O) {
//                            upCountO++;
//                        }
//                    }
//                    case 3 -> {
//                        if (nextInStreak[3] != 0 && mark == Mark.X) {
//                            downCountX++;
//                        }
//                        if (nextInStreak[3] != 0 && mark == Mark.O) {
//                            downCountO++;
//                        }
//                    }
//                    case 4 -> {
//                        if (nextInStreak[4] != 0 && mark == Mark.X) {
//                            leftUpCountX++;
//                        }
//                        if (nextInStreak[4] != 0 && mark == Mark.O) {
//                            leftUpCountO++;
//                        }
//                    }
//                    case 5 -> {
//                        if (nextInStreak[5] != 0 && mark == Mark.X) {
//                            leftDownCountX++;
//                        }
//                        if (nextInStreak[5] != 0 && mark == Mark.O) {
//                            leftDownCountO++;
//                        }
//                    }
//                    case 6 -> {
//                        if (nextInStreak[6] != 0 && mark == Mark.X) {
//                            rightUpCountX++;
//                        }
//                        if (nextInStreak[6] != 0 && mark == Mark.O) {
//                            rightUpCountO++;
//                        }
//                    }
//                    case 7 -> {
//                        if (nextInStreak[7] != 0 && mark == Mark.X) {
//                            rightDownCountX++;
//                        }
//                        else if (nextInStreak[7] != 0 && mark == Mark.O) {
//                            rightDownCountO++;
//                        }
//                    }
//                }
//                if (mark == Mark.X) {
//                    if (rightCountX == this.winStreak || leftCountX == this.winStreak || upCountX == this.winStreak ||
//                            downCountX == this.winStreak || rightUpCountX == this.winStreak ||
//                            rightDownCountX == this.winStreak || leftUpCountX == this.winStreak ||
//                            leftDownCountX == this.winStreak) {
//                        return true;
//                    }
//                }
//                else {
//                        if (rightCountO == this.winStreak || leftCountO == this.winStreak || upCountO == this.winStreak ||
//                                downCountO == this.winStreak || rightUpCountO == this.winStreak ||
//                                rightDownCountO == this.winStreak || leftUpCountO == this.winStreak ||
//                                leftDownCountO == this.winStreak) {
//                            return true;
//                        }
//                }
//            }
//        }
//        return false;
//    }

    /*
     * checkForPossibleWin - a function that check for a possible win,
     * after the player puts a Mark in the board.
     */
//    private void checkForPossibleWin(Mark mark, int row, int col) {
//        // checking for a possible win in any direction {row, column, diagonal}
//        if (checkAllDirections(mark)) {
//            setWinner(mark);
//            this.boardIsActive = false;
//            return;
//        }
//        if (isBoardFull()) {
//            this.boardIsActive = false;
//        }
//    }
}
