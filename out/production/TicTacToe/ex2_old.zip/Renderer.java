/**
 * a renderer interface.
 * <p>
 * an interface that represents a general renderer type
 * the renderers that implements this interface, have to implement their own renderBoard function.
 */
public interface Renderer {
    /**
     * each class that implements Player interface should implement this function
     * each renderer type will determine and implement his own printing strategy
     *
     * @param board the board to print.
     */
    void renderBoard(Board board);
}