enum Mark {BLANK,X,O }
//    X(new String[]{"  X   X  ",
//            "    X    ",
//            "  X   X  "}), O(new String[]{"   OOO   ",
//            "  O   O  ",
//            "   OOO   "}), BLANK(new String[]{"         ",
//            "         ",
//            "         "});
//
//    private final String[] MARK;
//
//    Mark(String[] mark) {
//        this.MARK = mark;
//    }

