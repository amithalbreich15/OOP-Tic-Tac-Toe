/**
 * a PlayerFactory.
 * <p>
 * a design pattern that builds a player {human, whatever, clever, genius}
 *
 * @author Bar Cavia
 */
public class PlayerFactory {
    private static final String WHATEVER_PLAYER = "whatever";
    private static final String CLEVER_PLAYER = "clever";
    private static final String GENIUS_PLAYER = "genius";
    private static final String HUMAN_PLAYER = "human";

    /**
     * buildPlayer function - a function that builds a player according to the given playerType string.
     *
     * @param playerType represents a given player type that need to be constructed.
     * @return return a player if playerType is in {human, whatever, clever, snarypamts}, null otherwise
     */
    Player buildPlayer(String playerType) {
        Player player = null;
        switch (playerType) {
            case WHATEVER_PLAYER:
                player = new WhateverPlayer();
                break;
            case CLEVER_PLAYER:
                player = new CleverPlayer();
                break;
            case GENIUS_PLAYER:
                player = new GeniusPlayer();
                break;
            case HUMAN_PLAYER:
                player = new HumanPlayer();
                break;
            default:
                break;
        }
        return player;
    }

}

