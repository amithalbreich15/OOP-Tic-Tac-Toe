import java.util.Random;

public class GeniusPlayer implements Player {

    private int myLastTurn = 0;
    private int[] opponentNewTurn = {1,1};
    private int[] opponentPrevTurn = {0,0};
    private int gameTactic = 1;
    private int moveCount = 3;
    private final Random random = new Random();

    public void playTurn(Board board, Mark mark)
    {
        int randomCoord =0;
        int [] availableCoordinates = new int[board.getSize()* board.getSize()];
        int availableCoordinatesSize = 0;
        Mark opponentMark = Mark.O;
        if (mark == Mark.O) {
            opponentMark = Mark.X;
        }
        for (int row = 0; row < board.getSize(); row++) {
            for (int col = 0; col < board.getSize(); col++) {
                if (board.getMark(row,col) == opponentMark && gameTactic == 1){
                    if (col + 1 < board.SIZE){
                        board.putMark(mark,row, ++col);
                        gameTactic = 2;
                    }
//                    myLastTurn = 10 * row + col;
                    return;
                }
                else if ( row == col && gameTactic == 2 )
                {
                    if (col +1 <board.SIZE && row +1 <board.SIZE){
                        while (!board.putMark(mark,row+1,col+1)) {
                            col++;
                            row++;
                            if (row >= board.SIZE || col >= board.SIZE) {
                                gameTactic = 1;
                                break;
                            }
                        }
                    }
                }
            }
        }
        for (int row=0; row <board.SIZE; row++) {
            for (int col = 0; col < board.SIZE; col++) {
                if (board.getMark(row, col) == Mark.BLANK) {
                    availableCoordinates[availableCoordinatesSize++] = 10 * row + col;
                }
            }
        }
        if (availableCoordinatesSize != 0){
            randomCoord = random.nextInt(availableCoordinatesSize);
        }
        int col = availableCoordinates[randomCoord] % 10;
        int row = availableCoordinates[randomCoord] / 10;
        board.putMark(mark, row, col);
    }
//        for (int row = 0; row < board.getSize(); row++) {
//            for(int col = 0; col < board.getSize(); col++) {
//                if (mark == Mark.X && isBoardEmpty(board)) {
//                    board.putMark(mark, row, col);
//                    return;
//                }
//                else if (mark == Mark.O && isBoardEmpty(board)) {
//                    int nextMove = checkSurroundings(board, Mark.O, 11, 1);
//                    board.putMark(mark, nextMove /10, nextMove % 10);
//                    return;
//                }
//                else if (board.getMark(row,col) == mark) {
//                    int previousTurns = 10*(row+1) + col+1;
//                    int nextMove = checkSurroundings(board, mark, previousTurns, 1);
//                    int[] rowAndCol = extractRowCol(nextMove);
//                    int newRow = rowAndCol[0];
//                    int newCol = rowAndCol[1];
//                    board.putMark(mark,newRow,newCol);
//                    return;
////                    int nextTurn = checkSurroundings(board,mark, previousTurns);
//                }
//            }
//        }
//    }

//    private int checkBestNextTurn

    private int checkSurroundings(Board board, Mark mark, int previousTurns, int coordLevel) {
        int left = previousTurns - coordLevel;
        int right = previousTurns + coordLevel;
        int up = previousTurns - 10*coordLevel;
        int down = previousTurns + 10*coordLevel;
        int leftUp = previousTurns - 11*coordLevel;
        int rightUp = previousTurns + 9*coordLevel;
        int leftDown = previousTurns - 9*coordLevel;
        int rightDown = previousTurns + 11*coordLevel;
        int[] movesToCheck = new int[]{left,right,up,down, leftUp, leftDown, rightUp, rightDown};
        int[] legalMovesFirst = findLegalMoves(board,mark,movesToCheck);
        int[] legalMovesSecond = findLegalMoves(board,mark,legalMovesFirst);
        for (int i = 0; i < legalMovesFirst.length; i++) {
            for (int j=0; j < legalMovesSecond.length; j++) {
                if (legalMovesFirst[i] != 0 && legalMovesSecond[j] != 0 && i == j) {
                    return legalMovesFirst[i];
                }
            }
        }
        int i = 0;
        while (i < legalMovesFirst.length - 1)
        {
            if (legalMovesFirst[i] != 0) {
                break;
            }
            i++;
        }
        return legalMovesFirst[i];
    }

    private int[] extractRowCol(int Coordinate) {
        int row = Coordinate / 10;
        int col = Coordinate % 10;
        return new int[]{row,col};
    }

    private int[] findLegalMoves(Board board, Mark mark, int[] movesToCheck) {
        int maxMoves = 8;
        int[] legalMoves = new int[maxMoves];
        int numValues = 0;
        for (int move = 0; move < maxMoves; move++) {
            int[] rowAndCol = extractRowCol(movesToCheck[move]);
            int row = rowAndCol[0];
            int col = rowAndCol[1];
            if ((board.getMark(row,col) == Mark.BLANK) && isLegalMove(board,movesToCheck[move])) {
                legalMoves[move] = movesToCheck[move];
            }
        }
        return legalMoves;
    }

    private boolean isLegalMove (Board board, int Coordinate) {
        int[] rowAndCol = extractRowCol(Coordinate);
        int row = rowAndCol[0];
        int col = rowAndCol[1];
        return row > 0 && col > 0 && row <= board.getSize() && col <= board.getSize();
    }

    private boolean isBoardEmpty (Board board) {
        int blankCounter = 0;
        for (int row = 0; row < board.getSize(); row++) {
            for (int col = 0; col < board.getSize(); col++) {
                if (board.getMark(row,col) == Mark.BLANK) {
                    blankCounter++;
                }
            }
        }
        return blankCounter == board.SIZE * board.SIZE;
    }

//     public void playTurn(Board board, Mark mark)
//     {
//         Mark opponentMark = Mark.O;
//         if (mark == Mark.O) {
//             opponentMark = Mark.X;
//         }
//         for (int row = 0; row < board.getSize(); row++) {
//             for (int col = 0; col < board.getSize(); col++) {
//                 if (board.getMark(row, col) != mark && board.getMark(row,col) != Mark.BLANK) {
//                     this.opponentPrevTurn[0] = this.opponentNewTurn[0];
//                     this.opponentPrevTurn[1] = this.opponentNewTurn[1];
//                     this.opponentNewTurn[0] = row;
//                     this.opponentNewTurn[1] = col;
//                     if (board.getMark(this.opponentNewTurn[0], this.opponentNewTurn[1]) == opponentMark) {
//                         if (col + 1 < board.getSize()) {
//                             board.putMark(mark, row, col + 1);
//                         }
//                     }
//                     return;
//                 }
//                 if (board.getMark(this.opponentNewTurn[0], this.opponentNewTurn[1]) == opponentMark &&
//                         board.getMark(this.opponentNewTurn[0] + 1, this.opponentNewTurn[1]) == opponentMark) {
//                     if (col + 2 < board.getSize()) {
//                         board.putMark(mark,row + 2, col);
//                     }
//                     return;
//                 }
//                 if (board.getMark(this.opponentNewTurn[0], this.opponentNewTurn[1]) == opponentMark &&
//                         board.getMark(this.opponentNewTurn[0] + 1, this.opponentNewTurn[1] + 1) == opponentMark) {
//                     if (col + 2 < board.getSize() && row + 2 < board.getSize()) {
//                         board.putMark(mark,row + 2, col +2);
//                     }
//                     return;
//                 }
//                 if (board.getMark(this.opponentNewTurn[0], this.opponentNewTurn[1]) == opponentMark &&
//                         board.getMark(this.opponentNewTurn[0] - 1, this.opponentNewTurn[1] + 1) == opponentMark) {
//                     if (col + 2 < board.getSize() && row - 2 < board.getSize()) {
//                         board.putMark(mark,row - 2, col + 2);
//                     }
//                     return;
//                 }
//                 else if (row == col && board.getMark(row, col) == Mark.BLANK) {
//                     board.putMark(mark, row, col);
//                     this.myLastTurn[0] = row;
//                     this.myLastTurn[1] = col;
//                     return;
//                 }
//                 else if (row == col && board.getMark(row, col) != Mark.BLANK) {
//                     while (!board.putMark(mark, row+1, col)) {
//                         row++;
//                         if (row == board.getSize()) {
//                             col++;
//                         }
//                     }
//                     this.myLastTurn[0] = row;
//                     this.myLastTurn[1] = col;
//                     return;
//                 }
//                 else if (row == col -1 || row - 1 == col) {
//                     while (!board.putMark(mark,row,col+1)) {
//                         col++;
//                     }
//                     this.myLastTurn[0] = row;
//                     this.myLastTurn[1] = col;
//                     return;
//                 }
//             }
//         }
//     }

//    private int checkDown
}
