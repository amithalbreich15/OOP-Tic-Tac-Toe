public class CleverPlayer implements Player {
    private int[] lastTurn = new int[2];

    public void playTurn(Board board, Mark mark)
    {
//        int[] lastTurn = new int[2];
        for (int row = 0; row < board.getSize(); row++) {
            for (int col = 0; col < board.getSize(); col++) {
                if (board.getMark(row, col) == Mark.BLANK) {
                    board.putMark(mark, row, col);
                    this.lastTurn[0] = row;
                    this.lastTurn[1] = col;
                    return;
                }
            }
        }
//        boolean result;
//        for (int row = 0; row < board.getSize(); row++) {
//            for (int col = 0; col < board.getSize(); col++) {
//                if (row == col && board.getMark(row, col) == Mark.BLANK) {
//                    board.putMark(mark, row, col);
//                    return;
//                }
//                else if (row == col && board.getMark(row, col) != Mark.BLANK) {
//                    result = board.putMark(mark, row+1, col);
//                    if (result) {
//                        return;
//                    }
//                }
//                else if (row == col) {
//                    board.putMark(mark, row, col+1);
//                    return;
//                }
//            }
//        }
    }
}
