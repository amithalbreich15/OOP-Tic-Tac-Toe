import java.util.*;

public class WhateverPlayer implements Player {
    private static final int BASE = 10;
    private final Random random = new Random();

    public void playTurn(Board board, Mark mark)
    {
        int randomCoord = 0;
        int [] availableCoordinates = new int[board.getSize()* board.getSize()];
        int availableCoordinatesSize = 0;
        for (int row=0; row <board.SIZE; row++) {
            for (int col=0; col <board.SIZE; col++) {
                if (board.getMark(row, col) == Mark.BLANK) {
                    availableCoordinates[availableCoordinatesSize++] = 10 * row + col;
//                    availableCoordinatesSize++;
                }
            }
        }
        if (!isBoardFull(board)) {
            randomCoord = random.nextInt(availableCoordinatesSize);
        }
        int col = availableCoordinates[randomCoord] % 10;
        int row = availableCoordinates[randomCoord] / 10;
        board.putMark(mark, row, col);
    }

    private boolean isBoardFull (Board board) {
        int blankCounter = 0;
        for (int row = 0; row < board.getSize(); row++) {
            for (int col = 0; col < board.getSize(); col++) {
                if (board.getMark(row,col) == Mark.BLANK) {
                    blankCounter++;
                }
            }
        }
        return blankCounter == 0;
    }
}
