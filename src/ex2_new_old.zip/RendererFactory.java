/**
 * a rendererFactory.
 * <p>
 * a design pattern that builds a render {console, none}
 *
 * @author Bar Cavia
 */
public class RendererFactory {
    private static final String CONSOLE = "console";
    private static final String NONE = "none";
//    private final int SIZE = 0;

    /**
     * buildPlayer function - a function that builds a player according to the given playerType string.
     *
     * @param rendererType represents a given render type that need to be constructed.
     * @return return a render if renderType is in {console, none}, null otherwise
     */
    Renderer buildRenderer(String rendererType, int size) {
        Renderer renderer = null;
        switch (rendererType) {
            case CONSOLE:
                renderer = new ConsoleRenderer(size);
                break;
            case NONE:
                renderer = new VoidRenderer();
                break;
            default:
                break;
        }
        return renderer;
    }
}

