/**
 * a voidRenderer.
 * <p>
 * this render type prints nothing to the console.
 * intended mostly for bots players.
 *
 */
public class VoidRenderer implements Renderer {

    /**
     * prints nothing to the console.
     * @param board represents the board to print.
     */
    @Override
    public void renderBoard(Board board) {
    }

}