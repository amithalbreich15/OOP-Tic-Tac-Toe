public class Tournament {

    private Player firstPlayer;
    private Player secondPlayer;
    private Renderer RENDERER;
    private int roundCounter;
    private int[] tournamentResults;

    private static final int FIRST_PLAYER = 0;
    private static final int SECOND_PLAYER = 1;
    private static final int DRAW_IND = 2;
    private static final int DEFAULT_PLAYERS_NUM = 2;

    // arguments constants
    /**
     * represents the valid num of program arguments
     */
    public static final int NUM_ARGS = 6;
    /**
     * represents the rounds index in the program arguments
     */
    public static final int ROUNDS_ARG = 0;
    /**
     * represents the board's size in the program arguments
     */
    public static final int SIZE_ARG = 1;
    /**
     * represents the win streak count in the program arguments
     */
    public static final int WIN_STREAK_ARG = 2;
    /**
     * represents the render type index in the program arguments
     */
    public static final int RENDERER_ARG = 3;
    /**
     * represents the first player index in the program arguments
     */
    public static final int PLAYER_ONE_ARG = 4;
    /**
     * represents the second player index in the program arguments
     */
    public static final int PLAYER_TWO_ARG = 5;
    /**
     * represents a valid usage of the command line arguments - will be printed in case on wrong input
     */
    public static final String USAGE_MSG = "Usage: Java Tournament [round count] [size] [win_streak] [render target: console/none]\n" +
            "[player: human/whatever/clever/genius]⨉2 ";
    private static final String INVALID_RENDERER_ERR = "Invalid Renderer type, Renderer type must be console/none please try again.";
    private static final String BOARD_SIZE_ERR = "Invalid board size, board size must be greater than 0 please try again.";
    private static final String ROUNDS_ERR = "Invalid rounds given, tournament rounds must be greater than 0 please try again.";
    private static final String WIN_STREAK_ERR = "Invalid win streak given, win streak must be greater than 0 please try again.";

    public Tournament(int rounds, Renderer renderer, Player[] players) {
        this.firstPlayer = players[FIRST_PLAYER];
        this.secondPlayer = players[SECOND_PLAYER];
        this.RENDERER = renderer;
        this.roundCounter = rounds;
        this.tournamentResults = new int[]{0, 0, 0};
    }

//    private void updateResults(Mark result, int playerSelector) {
//        // playerSelector helps to distinguish between the first player to the second player.
//        // if we got here, that means it was a draw round
//        switch (result) {
//            case X:
//                tournamentResults[playerSelector % DEFAULT_PLAYERS_NUM]++;
//            case O:
//                tournamentResults[(playerSelector + 1) % DEFAULT_PLAYERS_NUM]++;
//            default:
//                tournamentResults[DRAW_IND]++;
//        }
//    }

    public void playTournament(int size, int winStreak, String[] playerNames) {
        Game game;
        int playerWinsX = 0;
        int playerWinsO = 0;
        int tiesCount = 0;
        int playerSelector = 2;
        int roundCount = 0;
        while (roundCount < this.roundCounter) {
            game = buildNewGame(this.firstPlayer, this.secondPlayer, size, winStreak, this.RENDERER,  playerSelector);
            Mark result = game.run();
            roundCount++;
            playerSelector++;
            if (result == Mark.X)
            {
                playerWinsX++;
            }
            else if (result == Mark.O) {
                playerWinsO++;
            }
            else {
                tiesCount++;
            }
        }
        printTournamentResults(playerNames, tiesCount, playerWinsX, playerWinsO);
    }

    private Game buildNewGame(Player firstPlayer, Player secondPlayer,int size, int winStreak, Renderer renderer, int playerSelector) {
        if (playerSelector % DEFAULT_PLAYERS_NUM == 1) {
            return new Game(firstPlayer,secondPlayer,size, winStreak, renderer);
        }
        return new Game(firstPlayer,secondPlayer,size, winStreak,  renderer);
    }

    public static void main(String[] args) {
        if (areArgumentsValid(args)) {
            PlayerFactory playerFactory = new PlayerFactory();
            RendererFactory rendererFactory = new RendererFactory();
            int boardSize = Integer.parseInt(args[SIZE_ARG]);
            int winStreak = Integer.parseInt(args[WIN_STREAK_ARG]);
            int rounds = Integer.parseInt(args[ROUNDS_ARG]);
            Player firstPlayer = playerFactory.buildPlayer(args[PLAYER_ONE_ARG]);
            Player secondPlayer = playerFactory.buildPlayer(args[PLAYER_TWO_ARG]);
            String[] playerNames = new String[]{args[PLAYER_ONE_ARG], args[PLAYER_TWO_ARG]};
//            String rendererType = args[RENDERER_ARG];
            Renderer renderer;
            renderer = rendererFactory.buildRenderer(args[RENDERER_ARG],Integer.parseInt(args[SIZE_ARG]));
//            Renderer renderer = rendererFactory.buildRenderer(args[RENDERER_ARG],Integer.parseInt(args[SIZE_ARG]));
            // checking if the user has inserted an invalid player/renderer type
            if (firstPlayer == null || secondPlayer == null || renderer == null) {
                System.err.println(INVALID_RENDERER_ERR);
                return;
            }
            Player[] players = {firstPlayer, secondPlayer};
            Tournament newTournament = new Tournament(rounds, renderer, players);
            newTournament.playTournament(boardSize, winStreak, playerNames);
        }

    }

    private static boolean areArgumentsValid(String[] args) {
        if (args.length != NUM_ARGS) {
            System.err.println(USAGE_MSG);
            return false;
        }
        int boardSize = Integer.parseInt(args[SIZE_ARG]);
        int winStreakNum = Integer.parseInt(args[WIN_STREAK_ARG]);
        int roundsNum = Integer.parseInt(args[ROUNDS_ARG]);
        if (boardSize <= 0) {
            System.err.println(BOARD_SIZE_ERR);
            return false;
        }
        if (winStreakNum <= 0) {
            System.err.println(ROUNDS_ERR);
            return false;
        }
        if (roundsNum <= 0) {
            System.err.println(WIN_STREAK_ERR);
            return false;
        }
        return true;
    }

    private void printTournamentResults(String[] playerNames, int tiesCount, int playerWinsX, int playerWinsO) {
        System.out.println("######## Results #########");
        System.out.println("Player 1, " + playerNames[0] + " won: " + playerWinsX + " rounds");
        System.out.println("Player 2, " + playerNames[1] + " won: " + playerWinsO + " rounds");
        System.out.println("Ties: " + tiesCount);
    }
}

