import java.util.Scanner;

public class HumanPlayer implements Player {

    private static final String INPUT_REQUEST = "Player <mark>, type coordinates: ";
    private static final String MARK = "<mark>";
    private static final String INVALID_INPUT = "Invalid coordinates, type again: ";
    private static final int BASE = 10;

    HumanPlayer() { }

    public void playTurn(Board board, Mark mark)
    {
        Scanner userInput = new Scanner(System.in);
        System.out.println(INPUT_REQUEST.replaceAll(MARK, mark.toString()));
        int userCoordinatesChoice = userInput.nextInt();
        int col = (userCoordinatesChoice % 10);
        int row = (userCoordinatesChoice / 10);
        while (!board.putMark(mark, row, col)) {
            System.out.println(INVALID_INPUT);
            userCoordinatesChoice = userInput.nextInt();
            col = (userCoordinatesChoice % 10);
            row = (userCoordinatesChoice / 10);
        }

    }


}
