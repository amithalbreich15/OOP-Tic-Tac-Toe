public class Game {

    private final Player playerX;
    private final Player playerO;
    private final Renderer RENDERER;
    private int SIZE;
    private int winStreak;
    private boolean gameInProgress = false;
    private int marksCounter = 0;

    private static final int NUM_OF_PLAYERS = 2;
    private Mark winnerMark = Mark.BLANK;

    public Game(Player playerX, Player playerO, Renderer renderer) {
        this.playerX = playerX;
        this.playerO = playerO;
        this.RENDERER = renderer;
    }

    public Game(Player playerX, Player playerO,int size, int winStreak, Renderer renderer) {
        this.playerX = playerX;
        this.playerO = playerO;
        Board myBoard = new Board(size);
        this.SIZE = size;
        if (winStreak > myBoard.SIZE || winStreak <= 0) {
            this.winStreak = size;
        }
        else {
            this.winStreak = winStreak;
        }
        this.RENDERER = renderer;
    }

    public int getWinStreak() {
        return this.winStreak;
    }

    public Mark run() {
//        Game newGame = new Game(this.playerX,this.playerO,this.SIZE,this.winStreak,this.RENDERER);

        Board gameBoard = new Board(this.SIZE);
//        gameBoard.winStreak = this.winStreak;
        Player[] players = {this.playerX, this.playerO};
        Mark[] marks = {Mark.X, Mark.O};
        int playerSelector = 0;
        Mark gameWinner = Mark.BLANK;
        this.gameInProgress = true;
        while (!this.gameFinished()) {
            this.RENDERER.renderBoard(gameBoard);
            // deciding which player supposed to play
            players[playerSelector % NUM_OF_PLAYERS].playTurn(gameBoard,
                    marks[playerSelector % NUM_OF_PLAYERS]);
            this.marksCounter++;
            decideWinnerIdentity(gameBoard, marks[playerSelector % NUM_OF_PLAYERS],0,0);
            playerSelector++;
            gameWinner = this.getWinner();
        }
        this.RENDERER.renderBoard(gameBoard);
        this.gameInProgress = false;
        System.out.println("Player " + gameWinner.toString() + " won the game!");
        return gameWinner;
//        Board myBoard = new Board();
//        Player[] players = {this.playerX, this.playerO};
//        Mark[] marks = {Mark.X, Mark.O};
//        while (!myBoard.gameFinished()) {
//            this.RENDERER.renderBoard(myBoard);
//        }
//        this.RENDERER.renderBoard(myBoard);
//        return marks[0];
    }

    /*
     * isFullBoard function - check if the board is full of marks.
     */
    private boolean isBoardFull() {
        return this.marksCounter == SIZE * SIZE;
    }

    private Mark getWinner() {
        return this.winnerMark;
    }

    private void setWinner(Mark mark) {
        this.winnerMark = mark;
    }

    /**
     * gameEnded method - a method that checks if the game has ended
     *
     * @return true if tha game has ended (can be ended with a win/draw), false otherwise
     */
    private boolean gameFinished() {
        return !gameInProgress;
    }

    private int extractRow(int Coordinate) {
        return Coordinate / 10;
    }

    private int extractCol(int Coordinate) {
        return Coordinate % 10;
    }

    private boolean isLegalMove(Board board, int Coordinate) {
        int row = extractRow(Coordinate);
        int col = extractCol(Coordinate);
        return row >= 0 && col >= 0 && row < board.getSize() && col < board.getSize();
    }

    private boolean checkDiagonalDown(Board board, Mark mark, int row, int col) {
        int diagonalCount = 1;
        if (!isLegalMove(board, row*10*(winStreak -1) + col + (winStreak - 1)) || row + (winStreak) > board.getSize() || col + (winStreak) > board.getSize()) {
            return false;
        }
        for (int i = 0; i < this.winStreak - 1; i++) {
            if (board.getBoard()[row+1][col+1] == mark && board.getMark(row,col) == mark)
            {
                diagonalCount++;
                row++;
                col++;
            }
        }
        return diagonalCount == this.winStreak;
    }

    private boolean checkDiagonalUp(Board board, Mark mark, int row, int col) {
        int diagonalUpCount = 1;
        if (!isLegalMove(board, (row*10 + col)-(winStreak -1)*9) || row + (winStreak) > board.getSize() || col + (winStreak) > board.getSize()) {
            return false;
        }
        for (int i = 0; i < this.winStreak - 1; i++) {
            if (board.getBoard()[row-1][col+1] == mark && board.getMark(row,col) == mark)
            {
                diagonalUpCount++;
                row--;
                col++;
            }
        }
        return diagonalUpCount == this.winStreak;
    }

    private boolean checkHorizontal(Board board, Mark mark, int row, int col) {
        int horizontalCount = 1;
        if (!isLegalMove(board, row * 10 + col + (winStreak - 1)) || col + (winStreak) > board.getSize()) {
            return false;
        }
        for (int i = 0; i < this.winStreak -1; i++) {
            if (board.getBoard()[row][col + 1] == mark && board.getMark(row, col) == mark) {
                horizontalCount++;
                col++;
            }
        }
        return horizontalCount == this.winStreak;
    }

    private boolean checkVertical(Board board, Mark mark, int row, int col) {
        int verticalCount = 1;
        if (!isLegalMove(board, row*10*(winStreak - 1) + col) || row + (winStreak) > board.getSize()) {
            return false;
        }
        for (int i = 0; i < this.winStreak - 1; i++) {
            if (board.getBoard()[row+1][col] == mark && board.getMark(row,col) == mark)
            {
                row++;
                verticalCount++;
            }
        }
        return verticalCount == this.winStreak;
    }

    private boolean checkAllDirections(Board board, Mark mark) {
        for (int row = 0; row < this.SIZE; row++) {
            for (int col = 0; col < this.SIZE; col++) {
                if (checkVertical(board, mark, row, col) || checkHorizontal(board, mark, row, col) ||
                        checkDiagonalDown(board, mark, row, col) || checkDiagonalUp(board, mark, row, col)) {
                    return true;
                }
//                else {
//                    transposeBoard();
//                    boolean checkDiagonalUp = checkDiagonal(mark, row, col);
//                    transposeBoard();
//                    return checkDiagonalUp;
//                }
            }
        }
        return false;
    }

    /*
     * checkForPossibleWin - a function that check for a possible win,
     * after the player puts a Mark in the board.
     */
    private void decideWinnerIdentity(Board board, Mark mark, int row, int col) {
        // checking for a possible win in any direction {row, column, diagonal}
        if (checkAllDirections(board, mark)) {
            setWinner(mark);
            this.gameInProgress = false;
            return;
        }
        if (isBoardFull()) {
            this.gameInProgress = false;
        }
    }
}
